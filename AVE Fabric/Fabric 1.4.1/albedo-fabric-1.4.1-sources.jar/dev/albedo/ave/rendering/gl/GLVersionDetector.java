package dev.albedo.ave.rendering.gl;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL43;
import org.lwjgl.opengl.GLCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Detects OpenGL version and capabilities.
 * Allows graceful degradation for older GPU hardware.
 * 
 * @since 1.4.1
 */
@Environment(EnvType.CLIENT)
public class GLVersionDetector {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-gl");
    
    private static GLVersion detectedVersion = null;
    private static boolean hasSSBO = false;
    private static boolean hasShaderStorageBuffers = false;
    
    public enum GLVersion {
        GL_43("4.3+", 430, true),      // Full SSBO support
        GL_42("4.2", 420, false),      // No SSBO
        GL_41("4.1", 410, false),      // No SSBO
        GL_40("4.0", 400, false),      // No SSBO
        GL_33("3.3", 330, false),      // Deprecated SSBO
        GL_LEGACY("< 3.3", 0, false);  // Not supported
        
        public final String displayName;
        public final int version;
        public final boolean hasNativeSSBO;
        
        GLVersion(String displayName, int version, boolean hasNativeSSBO) {
            this.displayName = displayName;
            this.version = version;
            this.hasNativeSSBO = hasNativeSSBO;
        }
    }
    
    /**
     * Detect OpenGL version and capabilities.
     */
    public static void detect() {
        try {
            // Get version string
            String versionString = GL11.glGetString(GL11.GL_VERSION);
            String vendorString = GL11.glGetString(GL11.GL_VENDOR);
            String rendererString = GL11.glGetString(GL11.GL_RENDERER);
            
            LOGGER.info("GL Version: {}", versionString);
            LOGGER.info("GL Vendor: {}", vendorString);
            LOGGER.info("GL Renderer: {}", rendererString);
            
            // Get capabilities
            GLCapabilities caps = GL.getCapabilities();
            
            // Detect version
            if (caps.OpenGL43) {
                detectedVersion = GLVersion.GL_43;
                hasSSBO = true;
                hasShaderStorageBuffers = true;
                LOGGER.info("✓ Detected OpenGL 4.3 with full SSBO support");
            } else if (caps.OpenGL42) {
                detectedVersion = GLVersion.GL_42;
                hasSSBO = caps.GL_ARB_shader_storage_buffer_object;
                hasShaderStorageBuffers = hasSSBO;
                LOGGER.info("✓ Detected OpenGL 4.2 (SSBO: {})", hasSSBO);
            } else if (caps.OpenGL41) {
                detectedVersion = GLVersion.GL_41;
                hasSSBO = caps.GL_ARB_shader_storage_buffer_object;
                hasShaderStorageBuffers = hasSSBO;
                LOGGER.info("✓ Detected OpenGL 4.1 (SSBO: {})", hasSSBO);
            } else if (caps.OpenGL40) {
                detectedVersion = GLVersion.GL_40;
                hasSSBO = caps.GL_ARB_shader_storage_buffer_object;
                hasShaderStorageBuffers = hasSSBO;
                LOGGER.info("⚠ Detected OpenGL 4.0 (SSBO: {})", hasSSBO);
            } else if (caps.OpenGL33) {
                detectedVersion = GLVersion.GL_33;
                hasSSBO = caps.GL_ARB_shader_storage_buffer_object;
                hasShaderStorageBuffers = hasSSBO;
                LOGGER.warn("⚠ Detected OpenGL 3.3 (SSBO: {})", hasSSBO);
            } else {
                detectedVersion = GLVersion.GL_LEGACY;
                hasSSBO = false;
                hasShaderStorageBuffers = false;
                LOGGER.error("✗ OpenGL < 3.3 detected - Albedo will not function");
            }
            
        } catch (Exception e) {
            LOGGER.error("Failed to detect OpenGL version", e);
            detectedVersion = GLVersion.GL_LEGACY;
        }
    }
    
    /**
     * Get detected OpenGL version.
     */
    public static GLVersion getVersion() {
        if (detectedVersion == null) {
            detect();
        }
        return detectedVersion;
    }
    
    /**
     * Check if SSBO is supported.
     */
    public static boolean supportsSSBO() {
        if (detectedVersion == null) {
            detect();
        }
        return hasSSBO;
    }
    
    /**
     * Check if minimum version is met (GL 4.0).
     */
    public static boolean isSupported() {
        if (detectedVersion == null) {
            detect();
        }
        return detectedVersion.version >= 400;
    }
    
    /**
     * Check if full support (GL 4.3 with SSBO).
     */
    public static boolean hasFullSupport() {
        if (detectedVersion == null) {
            detect();
        }
        return detectedVersion == GLVersion.GL_43 && hasSSBO;
    }
    
    /**
     * Get support level as string.
     */
    public static String getSupportLevel() {
        if (!isSupported()) {
            return "NOT_SUPPORTED";
        }
        if (hasFullSupport()) {
            return "FULL_SUPPORT";
        }
        if (supportsSSBO()) {
            return "PARTIAL_SUPPORT";
        }
        return "LEGACY_MODE";
    }
}
