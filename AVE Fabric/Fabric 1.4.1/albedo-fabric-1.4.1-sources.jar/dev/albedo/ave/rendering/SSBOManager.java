package dev.albedo.ave.rendering;

import dev.albedo.ave.core.BlockPropertyRegistry;
import dev.albedo.ave.rendering.gl.GLVersionDetector;
import org.lwjgl.opengl.GL45;
import org.lwjgl.opengl.GL43;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.IntBuffer;

/**
 * SSBO Manager with OpenGL version compatibility.
 * Gracefully degrades to UBO or immediate mode for older GPUs.
 * 
 * @since 1.4.1
 */
public class SSBOManager {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave");
    private static final SSBOManager INSTANCE = new SSBOManager();
    private static final int BINDING_POINT = 0;
    private static final int MIN_BUFFER_SIZE = 16;
    
    private int ssboBufferId = 0;
    private int bufferSize = 0;
    private boolean isInitialized = false;
    private boolean hasError = false;
    private RenderMode renderMode = RenderMode.UNKNOWN;
    
    public enum RenderMode {
        SSBO("SSBO (GL 4.3+)"),           // Full speed - Shader Storage Buffer Object
        UBO("UBO (GL 3.0+)"),             // Medium speed - Uniform Buffer Object
        IMMEDIATE("Immediate Mode"),       // Slow - No GPU caching
        DISABLED("Disabled"),             // Feature not available
        UNKNOWN("Unknown");               // Initial state
        
        public final String displayName;
        
        RenderMode(String displayName) {
            this.displayName = displayName;
        }
    }
    
    private SSBOManager() {}
    
    public static SSBOManager getInstance() {
        return INSTANCE;
    }
    
    /**
     * Initialize the buffer system based on GPU capabilities.
     */
    public synchronized void initialize() {
        if (isInitialized && !hasError) {
            return;
        }
        
        try {
            // Detect GL version
            GLVersionDetector.detect();
            
            if (!GLVersionDetector.isSupported()) {
                LOGGER.error("OpenGL 4.0+ required for AVE, found: {}", 
                    GLVersionDetector.getVersion().displayName);
                renderMode = RenderMode.DISABLED;
                hasError = true;
                return;
            }
            
            // Choose render mode based on capabilities
            if (GLVersionDetector.supportsSSBO()) {
                renderMode = RenderMode.SSBO;
                LOGGER.info("Using SSBO render mode ({})", GLVersionDetector.getVersion().displayName);
            } else if (GLVersionDetector.getVersion().version >= 300) {
                renderMode = RenderMode.UBO;
                LOGGER.info("SSBO not available, falling back to UBO mode");
            } else {
                renderMode = RenderMode.IMMEDIATE;
                LOGGER.warn("Neither SSBO nor UBO available, using immediate mode (slow)");
            }
            
            updateBuffer();
            isInitialized = true;
            hasError = false;
            
            LOGGER.info("✓ Render system initialized in {} mode", renderMode.displayName);
            
        } catch (Exception e) {
            LOGGER.error("Failed to initialize render system", e);
            renderMode = RenderMode.DISABLED;
            hasError = true;
        }
    }
    
    /**
     * Update the buffer based on current render mode.
     */
    public synchronized void updateBuffer() {
        BlockPropertyRegistry registry = BlockPropertyRegistry.getInstance();
        
        if (!registry.isDirty() && ssboBufferId != 0 && !hasError) {
            return;
        }
        
        try {
            int[] packedData = registry.packToBuffer();
            
            if (packedData.length == 0) {
                LOGGER.warn("No block attributes to upload");
                return;
            }
            
            switch (renderMode) {
                case SSBO:
                    uploadSSBO(packedData);
                    break;
                case UBO:
                    uploadUBO(packedData);
                    break;
                case IMMEDIATE:
                    // Immediate mode doesn't use buffers
                    LOGGER.debug("Using immediate mode - no buffer upload");
                    break;
                case DISABLED:
                    LOGGER.error("Render mode is disabled, cannot update buffer");
                    hasError = true;
                    return;
            }
            
            registry.clearDirtyFlag();
            hasError = false;
            
        } catch (Exception e) {
            LOGGER.error("Failed to update buffer", e);
            hasError = true;
        }
    }
    
    /**
     * Upload data as SSBO (GL 4.3+).
     */
    private void uploadSSBO(int[] data) {
        int requiredSize = Math.max(data.length, MIN_BUFFER_SIZE);
        boolean needsReallocation = ssboBufferId == 0 || bufferSize < requiredSize;
        
        if (needsReallocation) {
            if (ssboBufferId != 0) {
                LOGGER.debug("Reallocating SSBO: {} → {} ints", bufferSize, requiredSize);
                GL15.glDeleteBuffers(ssboBufferId);
            }
            
            try {
                ssboBufferId = GL45.glCreateBuffers();
                bufferSize = requiredSize;
                LOGGER.debug("Allocated SSBO buffer ({} ints)", requiredSize);
            } catch (Exception e) {
                throw new RuntimeException("Failed to allocate SSBO buffer", e);
            }
        }
        
        try {
            IntBuffer intBuffer = IntBuffer.allocate(data.length);
            intBuffer.put(data);
            intBuffer.flip();
            
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, ssboBufferId);
            GL15.glBufferData(GL43.GL_SHADER_STORAGE_BUFFER, intBuffer, GL15.GL_DYNAMIC_DRAW);
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
            
            LOGGER.debug("Uploaded {} block attributes via SSBO", data.length);
        } catch (Exception e) {
            throw new RuntimeException("Failed to upload SSBO data", e);
        }
    }
    
    /**
     * Upload data as UBO (GL 3.0+, fallback).
     */
    private void uploadUBO(int[] data) {
        int requiredSize = Math.max(data.length, MIN_BUFFER_SIZE);
        boolean needsReallocation = ssboBufferId == 0 || bufferSize < requiredSize;
        
        if (needsReallocation) {
            if (ssboBufferId != 0) {
                GL15.glDeleteBuffers(ssboBufferId);
            }
            ssboBufferId = GL31.glGenBuffers();
            bufferSize = requiredSize;
        }
        
        IntBuffer intBuffer = IntBuffer.allocate(data.length);
        intBuffer.put(data);
        intBuffer.flip();
        
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, ssboBufferId);
        GL15.glBufferData(GL31.GL_UNIFORM_BUFFER, intBuffer, GL15.GL_DYNAMIC_DRAW);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
        
        LOGGER.debug("Uploaded {} block attributes via UBO fallback", data.length);
    }
    
    /**
     * Bind buffer for rendering.
     */
    public void bind() {
        if (renderMode == RenderMode.SSBO && ssboBufferId != 0 && !hasError) {
            try {
                GL43.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, BINDING_POINT, ssboBufferId);
            } catch (Exception e) {
                LOGGER.error("Failed to bind SSBO", e);
                hasError = true;
            }
        }
    }
    
    /**
     * Unbind buffer after rendering.
     */
    public void unbind() {
        if (renderMode == RenderMode.SSBO) {
            try {
                GL43.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, BINDING_POINT, 0);
            } catch (Exception e) {
                LOGGER.error("Failed to unbind SSBO", e);
            }
        }
    }
    
    /**
     * Clean up GPU resources.
     */
    public synchronized void cleanup() {
        if (ssboBufferId != 0) {
            try {
                GL15.glDeleteBuffers(ssboBufferId);
                ssboBufferId = 0;
                bufferSize = 0;
                LOGGER.info("GPU resources cleaned up");
            } catch (Exception e) {
                LOGGER.error("Error during cleanup", e);
            }
        }
    }
    
    /**
     * Get current render mode.
     */
    public RenderMode getRenderMode() {
        return renderMode;
    }
    
    /**
     * Get current buffer size in ints.
     */
    public int getBufferSize() {
        return bufferSize;
    }
    
    /**
     * Check if system is functional.
     */
    public boolean isFunctional() {
        return !hasError && renderMode != RenderMode.DISABLED;
    }
    
    /**
     * Check if full performance (SSBO mode).
     */
    public boolean hasFullPerformance() {
        return renderMode == RenderMode.SSBO;
    }
}
