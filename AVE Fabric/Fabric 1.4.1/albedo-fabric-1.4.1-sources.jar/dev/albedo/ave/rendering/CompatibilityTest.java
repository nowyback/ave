package dev.albedo.ave.rendering;

import dev.albedo.ave.core.BlockPropertyRegistry;
import dev.albedo.ave.rendering.gl.GLVersionDetector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Simple test to verify the compatibility system works without OpenGL dependencies.
 * This can be used to test the basic functionality before full OpenGL integration.
 * 
 * @since 1.4.1
 */
public class CompatibilityTest {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-test");
    
    public static void runBasicTest() {
        LOGGER.info("=== AVE Compatibility System Test ===");
        
        try {
            // Test BlockPropertyRegistry
            BlockPropertyRegistry registry = BlockPropertyRegistry.getInstance();
            LOGGER.info("✓ BlockPropertyRegistry initialized");
            LOGGER.info("  - Registered blocks: {}", registry.getRegisteredCount());
            LOGGER.info("  - Is dirty: {}", registry.isDirty());
            
            // Test buffer packing
            int[] buffer = registry.packToBuffer();
            LOGGER.info("✓ Buffer packing works (size: {} ints)", buffer.length);
            
            // Test SSBOManager (without OpenGL)
            SSBOManager manager = SSBOManager.getInstance();
            LOGGER.info("✓ SSBOManager created");
            
            // Note: We can't test full OpenGL functionality without a GL context
            LOGGER.info("⚠ OpenGL tests require running Minecraft client");
            
            LOGGER.info("=== Compatibility Test PASSED ===");
            
        } catch (Exception e) {
            LOGGER.error("=== Compatibility Test FAILED ===", e);
        }
    }
}
