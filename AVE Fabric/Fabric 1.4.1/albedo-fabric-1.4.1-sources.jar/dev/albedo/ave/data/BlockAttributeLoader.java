package dev.albedo.ave.data;

import com.google.gson.*;
import dev.albedo.ave.core.BlockPropertyRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Loads and parses block attribute JSON configuration files.
 * Supports multiple config files merged with priority: custom > create > default
 * 
 * @since 1.4.1
 */
public class BlockAttributeLoader {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave");
    private static final Gson GSON = new GsonBuilder()
        .setPrettyPrinting()
        .serializeNulls()
        .create();
    
    private static final String CONFIG_DIR = "data/albedo/block_attributes";
    private static final String EXTERNAL_CONFIG_DIR = "config/albedo/block_attributes";
    private static final String[] CONFIG_FILES = {
        "default.json",
        "create.json",
        "custom.json"
    };
    
    private static final int CONFIG_VERSION = 1;
    private static volatile boolean isLoaded = false;
    
    public static void loadAllConfigs() {
        if (isLoaded) {
            LOGGER.debug("Block attributes already loaded, skipping reload");
            return;
        }
        
        BlockPropertyRegistry registry = BlockPropertyRegistry.getInstance();
        registry.reloadShaderMap();
        Map<String, BlockAttribute> mergedAttributes = new LinkedHashMap<>();
        
        int totalLoaded = 0;
        
        for (String filename : CONFIG_FILES) {
            try {
                Map<String, BlockAttribute> fileAttributes = loadConfigFile(filename);
                totalLoaded += fileAttributes.size();
                mergedAttributes.putAll(fileAttributes);
                LOGGER.info("Loaded '{}': {} blocks", filename, fileAttributes.size());
            } catch (Exception e) {
                LOGGER.warn("Failed to load config file '{}': {}", filename, e.getMessage());
            }
        }
        
        int registeredCount = registerAttributes(registry, mergedAttributes);
        
        LOGGER.info("Configuration loading complete: {} registered from {} loaded", 
            registeredCount, totalLoaded);
        isLoaded = true;
    }
    
    private static Map<String, BlockAttribute> loadConfigFile(String filename) throws Exception {
        Map<String, BlockAttribute> attributes = new LinkedHashMap<>();
        
        InputStream is = BlockAttributeLoader.class.getResourceAsStream("/" + CONFIG_DIR + "/" + filename);
        
        if (is != null) {
            return loadFromStream(is, "classpath:" + filename);
        }
        
        Path externalPath = Paths.get(EXTERNAL_CONFIG_DIR, filename);
        if (Files.exists(externalPath)) {
            try (InputStream fileStream = Files.newInputStream(externalPath)) {
                return loadFromStream(fileStream, "file:" + externalPath.toAbsolutePath());
            }
        }
        
        LOGGER.debug("Config file not found (optional): {}", filename);
        return attributes;
    }
    
    private static Map<String, BlockAttribute> loadFromStream(InputStream is, String source) 
            throws IOException, JsonSyntaxException {
        Map<String, BlockAttribute> attributes = new LinkedHashMap<>();
        
        try (InputStreamReader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            JsonElement element = JsonParser.parseReader(reader);
            if (!element.isJsonObject()) {
                throw new JsonSyntaxException("Config root must be a JSON object");
            }
            
            JsonObject root = element.getAsJsonObject();
            
            if (root.has("version")) {
                int version = root.get("version").getAsInt();
                if (version != CONFIG_VERSION) {
                    LOGGER.warn("Config '{}' has unsupported version: {} (expected {})", 
                        source, version, CONFIG_VERSION);
                    return attributes;
                }
            }
            
            if (root.has("blocks")) {
                JsonObject blocksObj = root.getAsJsonObject("blocks");
                
                for (String blockName : blocksObj.keySet()) {
                    try {
                        JsonElement blockElement = blocksObj.get(blockName);
                        if (!blockElement.isJsonObject()) {
                            LOGGER.warn("Block '{}' is not a JSON object", blockName);
                            continue;
                        }
                        
                        BlockAttribute attr = parseBlockAttribute(blockElement.getAsJsonObject());
                        attributes.put(blockName, attr);
                    } catch (Exception e) {
                        LOGGER.warn("Failed to parse block '{}' in {}: {}", 
                            blockName, source, e.getMessage());
                    }
                }
            }
            
            LOGGER.debug("Parsed {} blocks from {}", attributes.size(), source);
            return attributes;
            
        } catch (JsonSyntaxException e) {
            throw new IOException("Invalid JSON syntax in " + source + ": " + e.getMessage(), e);
        }
    }
    
    private static BlockAttribute parseBlockAttribute(JsonObject obj) {
        int scattering = getIntSafe(obj, "scattering", 0);
        int reflectivity = getIntSafe(obj, "reflectivity", 0);
        int roughness = getIntSafe(obj, "roughness", 0);
        int metallic = getIntSafe(obj, "metallic", 0);
        
        return new BlockAttribute(scattering, reflectivity, roughness, metallic);
    }
    
    private static int getIntSafe(JsonObject obj, String key, int defaultValue) {
        try {
            if (!obj.has(key)) {
                return defaultValue;
            }
            
            JsonElement element = obj.get(key);
            if (!element.isJsonPrimitive()) {
                LOGGER.warn("Key '{}' is not a primitive value", key);
                return defaultValue;
            }
            
            int value = element.getAsInt();
            if (value < 0 || value > 255) {
                LOGGER.warn("Value for key '{}' out of range [0, 255]: {}", key, value);
                return Math.max(0, Math.min(255, value));
            }
            
            return value;
        } catch (NumberFormatException e) {
            LOGGER.warn("Failed to parse integer for key '{}': {}", key, e.getMessage());
            return defaultValue;
        }
    }
    
    private static int registerAttributes(BlockPropertyRegistry registry, 
                                         Map<String, BlockAttribute> attributes) {
        int successCount = 0;
        int failureCount = 0;
        
        for (Map.Entry<String, BlockAttribute> entry : attributes.entrySet()) {
            String blockName = entry.getKey();
            BlockAttribute attribute = entry.getValue();
            
            try {
                class_2248 block = resolveBlock(blockName);
                if (block != null) {
                    registry.register(block, attribute);
                    successCount++;
                } else {
                    failureCount++;
                }
            } catch (Exception e) {
                LOGGER.debug("Failed to register block '{}': {}", blockName, e.getMessage());
                failureCount++;
            }
        }
        
        if (failureCount > 0) {
            LOGGER.info("Block registration: {} succeeded, {} failed", successCount, failureCount);
        }
        
        return successCount;
    }
    
private static class_2248 resolveBlock(String blockName) {
        try {
            String fullName = blockName.contains(":") ? blockName : "minecraft:" + blockName;
            
            class_2960 id = class_2960.method_60654(fullName);
            Optional<class_2248> blockOpt = class_7923.field_41175.method_17966(id);

            if (blockOpt.isEmpty()) {
                LOGGER.debug("Block not found in registry: {}", fullName);
                return null;
            }
            return blockOpt.get();
        } catch (Exception e) {
            LOGGER.debug("Invalid block identifier '{}': {}", blockName, e.getMessage());
            return null;
        }
    }
    
    public static void reload() {
        LOGGER.info("Reloading block attributes...");
        BlockPropertyRegistry.getInstance().clear();
        isLoaded = false;
        loadAllConfigs();
    }
    
    public static boolean isLoaded() {
        return isLoaded;
    }
}
