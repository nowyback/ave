package dev.albedo.ave.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import net.fabricmc.loader.api.FabricLoader;

public class ShaderpackPropertiesParser {

    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave");

    public static Map<String, Integer> getShaderBlockMappings() {
        Path gameDir = FabricLoader.getInstance().getGameDir();
        Map<String, Integer> mappings = new HashMap<>();
        try {
            Path optionsFile = gameDir.resolve("optionsshaders.txt");
            if (!Files.exists(optionsFile)) {
                LOGGER.warn("No optionsshaders.txt found. Cannot parse block.properties.");
                return mappings;
            }

            String activePack = null;
            for (String line : Files.readAllLines(optionsFile)) {
                if (line.startsWith("shaderPack=")) {
                    activePack = line.substring("shaderPack=".length()).trim();
                    break;
                }
            }

            if (activePack == null || activePack.equals("OFF") || activePack.equals("(internal)")) {
                LOGGER.warn("No active shaderpack found in optionsshaders.txt.");
                return mappings;
            }

            Path packPath = gameDir.resolve("shaderpacks").resolve(activePack);
            if (!Files.exists(packPath)) {
                LOGGER.warn("Active shaderpack not found: {}", packPath);
                return mappings;
            }

            if (Files.isDirectory(packPath)) {
                Path propFile = packPath.resolve("shaders").resolve("block.properties");
                if (Files.exists(propFile)) {
                    parsePropertiesStream(Files.newInputStream(propFile), mappings);
                }
            } else if (activePack.endsWith(".zip")) {
                try (ZipFile zipFile = new ZipFile(packPath.toFile())) {
                    ZipEntry entry = zipFile.getEntry("shaders/block.properties");
                    if (entry != null) {
                        parsePropertiesStream(zipFile.getInputStream(entry), mappings);
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to parse shader block.properties", e);
        }
        
        LOGGER.info("Successfully loaded {} custom block ID mappings from shaderpack.", mappings.size());
        return mappings;
    }

    private static void parsePropertiesStream(InputStream is, Map<String, Integer> out) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                // Match block.ID = blockName blockName
                if (line.startsWith("block.") && line.contains("=")) {
                    String[] parts = line.split("=", 2);
                    String idPart = parts[0].substring("block.".length()).trim();
                    String blocksPart = parts[1].trim();

                    try {
                        int id = Integer.parseInt(idPart);
                        String[] blockNames = blocksPart.split("\\s+");
                        for (String b : blockNames) { // support namespaces if missing
                            if (b.contains(":")) {
                                out.put(b, id);
                            } else {
                                out.put("minecraft:" + b, id);
                            }
                        }
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
    }
}
