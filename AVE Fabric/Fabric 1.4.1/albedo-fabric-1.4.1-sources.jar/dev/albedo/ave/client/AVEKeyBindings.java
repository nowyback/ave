package dev.albedo.ave.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AVE Key Bindings - Handles keyboard shortcuts for AVE features
 * 
 * @since 1.4.1
 */
public class AVEKeyBindings {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-keybinds");
    
    // Key binding for reloading AVE splash screen (Alt + B)
    private static class_304 reloadSplashKey;
    
    public static void register() {
        LOGGER.info("Registering AVE key bindings");
        
        // Create key binding: Alt + B
        reloadSplashKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.albedo.reload_splash",  // Translation key
            class_3675.class_307.field_1668,       // Key type
            GLFW.GLFW_KEY_B,             // B key
            "category.albedo.ave"        // Category
        ));
        
        // Register client tick event to handle key presses
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (reloadSplashKey.method_1436()) {
                // Check if Alt is held down
                if (isAltPressed()) {
                    LOGGER.info("Alt+B pressed - Reloading AVE splash screen");
                    reloadSplashScreen(client);
                }
            }
        });
        
        LOGGER.info("AVE key bindings registered successfully");
    }
    
    /**
     * Check if Alt key is currently pressed
     */
    private static boolean isAltPressed() {
        long window = net.minecraft.class_310.method_1551().method_22683().method_4490();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS ||
               GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
    }
    
    /**
     * Reload the AVE splash screen
     */
    private static void reloadSplashScreen(net.minecraft.class_310 client) {
        try {
            // Reset splash screen state
            dev.albedo.ave.client.ui.AVESplashScreen.reset();
            
            // Show splash screen again
            dev.albedo.ave.client.ui.AVESplashScreen.show();
            
            // Replace current screen with splash overlay
            if (!(client.field_1755 instanceof dev.albedo.ave.client.ui.SplashOverlayScreen)) {
                client.method_1507(new dev.albedo.ave.client.ui.SplashOverlayScreen());
            }
            
            LOGGER.info("AVE splash screen reloaded successfully");
            
        } catch (Exception e) {
            LOGGER.error("Failed to reload AVE splash screen", e);
        }
    }
}
