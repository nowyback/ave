#version 450 core

in VertexData {
    vec4 color;
    vec2 uv0;
    vec2 uv1;
    vec3 normal;
    vec3 position;
    flat uint blockID;
} vIn;

out vec4 FragColor;

// Include SSBO definitions
#include "/assets/albedo/shaders/core/ssbo_binding.glsl"

// Lighting
uniform sampler2D uTexture;
uniform sampler2D uNormalMap;
uniform vec3 uLightDirection;
uniform vec3 uViewPosition;

void main() {
    // Fetch block attributes from SSBO using block ID
    BlockData blockData = getBlockData(vIn.blockID);
    vec4 normalizedData = normalizeBlockData(blockData);
    
    // Extract properties
    float scattering = normalizedData.r;
    float reflectivity = normalizedData.g;
    float roughness = normalizedData.b;
    float metallic = normalizedData.a;
    
    // Sample base texture
    vec4 texColor = texture(uTexture, vIn.uv0);
    texColor *= vIn.color;
    
    // Basic Phong lighting with block properties
    vec3 lightDir = normalize(uLightDirection);
    vec3 viewDir = normalize(uViewPosition - vIn.position);
    vec3 halfDir = normalize(lightDir + viewDir);
    
    // Diffuse
    float diff = max(dot(vIn.normal, lightDir), 0.0);
    vec3 diffuse = vec3(diff);
    
    // Specular (using reflectivity and roughness)
    float spec = pow(max(dot(vIn.normal, halfDir), 0.0), 1.0 - roughness * 128.0);
    vec3 specular = vec3(spec * reflectivity);
    
    // Metallic: blend diffuse and specular
    vec3 base = mix(texColor.rgb, vec3(0.5), metallic);
    vec3 lit = base * (diffuse + 0.3) + specular;
    
    // Scattering: apply subsurface effect (optional)
    lit += texColor.rgb * scattering * 0.1;
    
    FragColor = vec4(lit, texColor.a);
}
