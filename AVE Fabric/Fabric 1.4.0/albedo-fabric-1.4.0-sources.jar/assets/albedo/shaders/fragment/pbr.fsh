#version 450 core

in VertexData {
    vec4 color;
    vec2 uv0;
    vec2 uv1;
    vec3 normal;
    vec3 position;
    flat uint blockID;
} vIn;

out vec4 FragColor;

#include "/assets/albedo/shaders/core/ssbo_binding.glsl"

uniform sampler2D uTexture;
uniform sampler2D uNormalMap;
uniform samplerCube uEnvironmentMap;
uniform vec3 uLightDirection;
uniform vec3 uViewPosition;

const float PI = 3.14159265359;

// GGX Normal Distribution Function
float DistributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;
    float nom = a2;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    return nom / (PI * denom * denom);
}

// Fresnel-Schlick
vec3 FresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

void main() {
    BlockData blockData = getBlockData(vIn.blockID);
    vec4 normalized = normalizeBlockData(blockData);
    
    float roughness = normalized.b;
    float metallic = normalized.a;
    
    vec3 texColor = texture(uTexture, vIn.uv0).rgb;
    vec3 N = normalize(vIn.normal);
    vec3 V = normalize(uViewPosition - vIn.position);
    vec3 L = normalize(uLightDirection);
    vec3 H = normalize(L + V);
    
    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 0.0);
    
    // F0: depends on metallic
    vec3 F0 = mix(vec3(0.04), texColor, metallic);
    
    // Cook-Torrance BRDF
    float D = DistributionGGX(N, H, roughness);
    vec3 F = FresnelSchlick(max(dot(H, V), 0.0), F0);
    
    vec3 kS = F;
    vec3 kD = (1.0 - kS) * (1.0 - metallic);
    
    // Specular
    vec3 specular = D * F / (4.0 * NdotV * NdotL + 0.0001);
    
    // Final color
    vec3 color = (kD * texColor / PI + specular) * NdotL;
    
    FragColor = vec4(color, 1.0);
}
