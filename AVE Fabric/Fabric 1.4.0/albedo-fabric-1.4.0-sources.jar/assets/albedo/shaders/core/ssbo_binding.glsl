// SSBO Layout Definition - Include in all shaders
// Binding point 0 = Block attributes buffer

layout(std430, binding = 0) readonly buffer BlockAttributes {
    uint attributes[];  // Packed RGBA: R=scatter, G=reflect, B=rough, A=metal
};

// Structure to hold unpacked block data
struct BlockData {
    uint scattering;
    uint reflectivity;
    uint roughness;
    uint metallic;
};

/**
 * Unpack a single block attribute from the SSBO.
 * Input: block ID
 * Output: BlockData with individual channels
 */
BlockData getBlockData(uint blockID) {
    uint packed = attributes[blockID];
    
    return BlockData(
        (packed & 0xFFu),           // R: scattering
        ((packed >> 8u) & 0xFFu),   // G: reflectivity
        ((packed >> 16u) & 0xFFu),  // B: roughness
        ((packed >> 24u) & 0xFFu)   // A: metallic
    );
}

/**
 * Convert byte values (0-255) to normalized floats (0.0-1.0)
 */
vec4 normalizeBlockData(BlockData data) {
    return vec4(
        float(data.scattering) / 255.0,
        float(data.reflectivity) / 255.0,
        float(data.roughness) / 255.0,
        float(data.metallic) / 255.0
    );
}
