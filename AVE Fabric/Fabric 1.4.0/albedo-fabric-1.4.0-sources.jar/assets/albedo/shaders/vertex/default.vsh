#version 450 core

// Vertex attributes (from Minecraft)
layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in vec2 UV1;
layout(location = 4) in vec3 Normal;

// Per-vertex block ID
flat in uint blockID;

// Output to fragment shader
out VertexData {
    vec4 color;
    vec2 uv0;
    vec2 uv1;
    vec3 normal;
    vec3 position;
    flat uint blockID;
} vOut;

// Include SSBO definitions
#include "/assets/albedo/shaders/core/ssbo_binding.glsl"

// Uniforms
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;

void main() {
    // Transform vertex position
    vec4 worldPos = uModel * vec4(Position, 1.0);
    gl_Position = uProjection * uView * worldPos;
    
    // Pass data to fragment shader
    vOut.color = Color;
    vOut.uv0 = UV0;
    vOut.uv1 = UV1;
    vOut.normal = normalize(mat3(uModel) * Normal);
    vOut.position = worldPos.xyz;
    vOut.blockID = blockID;
}
