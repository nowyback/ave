package dev.albedo.ave.data;

import com.google.gson.JsonObject;
import java.util.*;

/**
 * Utilities for validating configuration files.
 */
public class ConfigValidationUtils {
    
    private ConfigValidationUtils() {}
    
    public static List<String> validateBlockAttribute(String blockName, JsonObject blockObj) {
        List<String> errors = new ArrayList<>();
        
        if (blockName == null || blockName.isEmpty()) {
            errors.add("Block name cannot be empty");
        }
        
        validateIntRange(blockObj, "scattering", errors);
        validateIntRange(blockObj, "reflectivity", errors);
        validateIntRange(blockObj, "roughness", errors);
        validateIntRange(blockObj, "metallic", errors);
        
        return errors;
    }
    
    private static void validateIntRange(JsonObject obj, String key, List<String> errors) {
        if (!obj.has(key)) {
            return;
        }
        
        try {
            int value = obj.get(key).getAsInt();
            if (value < 0 || value > 255) {
                errors.add(String.format("'%s' must be in range [0, 255], got %d", key, value));
            }
        } catch (Exception e) {
            errors.add(String.format("'%s' must be an integer, got invalid value", key));
        }
    }
}
