package dev.albedo.ave.data;

import java.util.Objects;

/**
 * Immutable representation of block rendering attributes.
 * All 4 properties packed into a single 32-bit unsigned integer (RGBA).
 * 
 * @since 1.4.0
 */
public class BlockAttribute {
    
    public static final int SIZE_BYTES = 4;
    public static final int MAX_VALUE = 255;
    public static final int MIN_VALUE = 0;
    
    private static final String VALIDATION_FAILED = 
        "Block attribute values must be in range [0, 255], got: %s=%d";
    
    private final byte scattering;
    private final byte reflectivity;
    private final byte roughness;
    private final byte metallic;
    
    public BlockAttribute(int scattering, int reflectivity, int roughness, int metallic) {
        this.scattering = validateAndCast("scattering", scattering);
        this.reflectivity = validateAndCast("reflectivity", reflectivity);
        this.roughness = validateAndCast("roughness", roughness);
        this.metallic = validateAndCast("metallic", metallic);
    }
    
    private static byte validateAndCast(String name, int value) {
        if (value < MIN_VALUE || value > MAX_VALUE) {
            throw new IllegalArgumentException(
                String.format(VALIDATION_FAILED, name, value));
        }
        return (byte) value;
    }
    
    public int pack() {
        return ((metallic & 0xFF) << 24) 
             | ((roughness & 0xFF) << 16) 
             | ((reflectivity & 0xFF) << 8) 
             | (scattering & 0xFF);
    }
    
    public static BlockAttribute unpack(int packed) {
        int scattering = packed & 0xFF;
        int reflectivity = (packed >> 8) & 0xFF;
        int roughness = (packed >> 16) & 0xFF;
        int metallic = (packed >> 24) & 0xFF;
        
        return new BlockAttribute(scattering, reflectivity, roughness, metallic);
    }
    
    public int getScattering() { return scattering & 0xFF; }
    public int getReflectivity() { return reflectivity & 0xFF; }
    public int getRoughness() { return roughness & 0xFF; }
    public int getMetallic() { return metallic & 0xFF; }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof BlockAttribute)) return false;
        BlockAttribute other = (BlockAttribute) obj;
        return pack() == other.pack();
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(scattering, reflectivity, roughness, metallic);
    }
    
    @Override
    public String toString() {
        return String.format(
            "BlockAttribute{scatter=%d, reflect=%d, rough=%d, metal=%d}",
            getScattering(), getReflectivity(), getRoughness(), getMetallic());
    }
    
    public static BlockAttribute createDefault() {
        return new BlockAttribute(0, 0, 0, 0);
    }
}
