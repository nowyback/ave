package dev.albedo.ave.client.debug;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import dev.albedo.ave.core.BlockPropertyRegistry;
import dev.albedo.ave.rendering.SSBOManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Debug utilities for development and troubleshooting.
 */
@Environment(EnvType.CLIENT)
public class RenderDebugHelper {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-debug");
    
    public static void logState() {
        LOGGER.info("=== (d)AVE DEBUG STATE ===");
        
        BlockPropertyRegistry registry = BlockPropertyRegistry.getInstance();
        LOGGER.info("Registry:");
        LOGGER.info("  - Registered blocks: {}", registry.getRegisteredCount());
        LOGGER.info("  - Is dirty: {}", registry.isDirty());
        
        SSBOManager ssbo = SSBOManager.getInstance();
        LOGGER.info("SSBO:");
        LOGGER.info("  - Buffer size: {} ints ({} bytes)", ssbo.getBufferSize(), ssbo.getBufferSize() * 4);
        LOGGER.info("  - Functional: {}", ssbo.isFunctional());
        LOGGER.info("  - Render Mode: {}", ssbo.getRenderMode().displayName);
        
        LOGGER.info("=========================");
    }
    
    public static void reloadConfigs() {
        LOGGER.info("Reloading configurations...");
        try {
            BlockPropertyRegistry.getInstance().clear();
            LOGGER.info("✓ Reload complete");
        } catch (Exception e) {
            LOGGER.error("✗ Reload failed", e);
        }
    }
}
