package dev.albedo.ave.client;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_442;
import dev.albedo.ave.client.ui.AVESplashScreen;
import dev.albedo.ave.client.ui.SplashOverlayScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Splash Screen Handler - WORKING VERSION
 * Uses CLIENT_TICK event (which exists in Fabric)
 * Shows splash overlay on top of TitleScreen
 */
@Environment(EnvType.CLIENT)
public class SplashScreenHandler {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-splash-handler");
    private static boolean splashShownThisSession = false;
    private static boolean hasReachedTitleScreen = false;
    
    /**
     * Initialize splash screen system.
     * Call this from AVEClient.onInitializeClient()
     */
    public static void init() {
        LOGGER.info("Initializing splash screen handler with CLIENT_TICK");
        
        // Use CLIENT_TICK instead of SCREEN_OPEN (which doesn't exist in Fabric)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Only run once per session
            if (splashShownThisSession) {
                return;
            }
            
            // Wait for TitleScreen to appear
            if (client.field_1755 instanceof class_442 && !hasReachedTitleScreen) {
                hasReachedTitleScreen = true;
                LOGGER.info("TitleScreen detected, showing splash overlay");
                
                // Mark splash as shown
                splashShownThisSession = true;
                
                // Start splash animation
                AVESplashScreen.show();
                
                // Replace TitleScreen with splash overlay
                // The overlay will render the TitleScreen underneath
                client.method_1507(new SplashOverlayScreen());
                
                LOGGER.info("Splash overlay screen set");
            }
        });
        
        LOGGER.info("Splash screen handler initialized");
    }
}
