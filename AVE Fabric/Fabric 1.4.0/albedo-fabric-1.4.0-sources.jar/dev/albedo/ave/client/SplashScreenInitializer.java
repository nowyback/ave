package dev.albedo.ave.client;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_442;
import dev.albedo.ave.client.ui.AVESplashScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Initializes the AVE splash screen display.
 * Hooks into Minecraft's rendering pipeline to show splash after loading.
 */
@Environment(EnvType.CLIENT)
public class SplashScreenInitializer {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-splash");
    
    /**
     * Register splash screen to display when main menu would appear.
     */
    public static void init() {
        // Check for TitleScreen and start splash screen when it first appears
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1755 instanceof class_442) {
                // If splash hasn't started yet, start it now
                if (!AVESplashScreen.isActive() && !AVESplashScreen.hasCompleted()) {
                    LOGGER.info("TitleScreen detected, starting AVE splash screen");
                    AVESplashScreen.show();
                }
                
                // If splash is active, replace TitleScreen with our splash overlay
                if (AVESplashScreen.isActive()) {
                    LOGGER.debug("Blocking TitleScreen with splash overlay");
                    if (!(client.field_1755 instanceof dev.albedo.ave.client.ui.SplashOverlayScreen)) {
                        client.method_1507(new dev.albedo.ave.client.ui.SplashOverlayScreen());
                    }
                }
            }
        });
    }
}