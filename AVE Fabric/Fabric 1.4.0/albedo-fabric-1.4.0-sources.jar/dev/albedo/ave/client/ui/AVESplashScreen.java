package dev.albedo.ave.client.ui;

import net.fabricmc.api.Environment;
import net.minecraft.class_1043;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.fabricmc.api.EnvType;
import com.mojang.blaze3d.systems.RenderSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AVE Splash Screen - SIMPLE WORKING VERSION
 * No complications, just loads and displays the PNG.
 */
@Environment(EnvType.CLIENT)
public class AVESplashScreen {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-splash");
    
    // Timing
    private static final long FADE_IN = 600;
    private static final long DISPLAY = 2500;
    private static final long FADE_OUT = 600;
    private static final long TOTAL = FADE_IN + DISPLAY + FADE_OUT;
    
    // State
    private static long startTime = 0;
    private static boolean isShowing = false;
    private static boolean hasCompleted = false;
    private static class_2960 textureId;

    public static void show() {
        if (isShowing || hasCompleted) return;
        
        LOGGER.info("Splash screen starting");
        startTime = System.currentTimeMillis();
        isShowing = true;
        
        // Load texture immediately
        loadSplashTexture();
    }

    private static void loadSplashTexture() {
        try {
            String resourcePath = "/assets/albedo/textures/splash.png";
            
            var inputStream = AVESplashScreen.class.getResourceAsStream(resourcePath);
            if (inputStream == null) {
                LOGGER.error("Could not find: {}", resourcePath);
                LOGGER.error("PNG must be at: src/main/resources/assets/albedo/textures/splash.png");
                return;
            }
            
            // Read image
            var image = net.minecraft.class_1011.method_4309(inputStream);
            inputStream.close();
            
            LOGGER.info("Splash PNG loaded: {}x{} pixels", image.method_4307(), image.method_4323());
            
            // Create and register texture
            textureId = class_2960.method_60655("albedo", "splash_screen");
            var texture = new class_1043(image);
            class_310.method_1551().method_1531().method_4616(textureId, texture);
            
            LOGGER.info("Splash texture registered and ready");
            
        } catch (Exception e) {
            LOGGER.error("Failed to load splash texture", e);
            textureId = null;
        }
    }

    public static void renderSplashScreen(class_332 context, int screenWidth, int screenHeight) {
        if (!isShowing) return;
        
        long elapsed = System.currentTimeMillis() - startTime;
        
        // Check if done
        if (elapsed >= TOTAL) {
            isShowing = false;
            hasCompleted = true;
            LOGGER.info("Splash animation complete");
            return;
        }
        
        // Calculate alpha
        float alpha;
        if (elapsed < FADE_IN) {
            alpha = (float) elapsed / FADE_IN;
        } else if (elapsed < FADE_IN + DISPLAY) {
            alpha = 1.0f;
        } else {
            long fadeOut = elapsed - FADE_IN - DISPLAY;
            alpha = 1.0f - ((float) fadeOut / FADE_OUT);
        }
        
        alpha = Math.max(0, Math.min(1, alpha));
        
        // Draw background - ALWAYS render full black background to cover everything
        context.method_25294(0, 0, screenWidth, screenHeight, 0xFF000000);
        
        // Draw splash image if loaded
        if (textureId != null) {
            drawImage(context, screenWidth, screenHeight, alpha);
        } else {
            // Show error box if texture failed to load
            int x = screenWidth / 4;
            int y = screenHeight / 4;
            int w = screenWidth / 2;
            int h = screenHeight / 2;
            context.method_25294(x, y, x + w, y + h, 0xFF0000FF);  // Red error box
        }
    }

    private static void drawImage(class_332 context, int screenW, int screenH, float alpha) {
        try {
            // YOUR PNG SIZE - CHANGE THESE IF NEEDED
            int imgW = 1920;  // Change to your PNG width
            int imgH = 1080;  // Change to your PNG height
            
            // Scale to fit screen (70% of smallest dimension)
            float scale = Math.min((float) screenW / imgW, (float) screenH / imgH) * 0.7f;
            int scaledW = (int) (imgW * scale);
            int scaledH = (int) (imgH * scale);
            
            // Center
            int x = (screenW - scaledW) / 2;
            int y = (screenH - scaledH) / 2;
            
            // Setup rendering
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
            
            // Draw
            context.method_25290(
                class_1921::method_62277,
                textureId, x, y, 0f, 0f, scaledW, scaledH, imgW, imgH
            );
            
            // Reset
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
            RenderSystem.disableBlend();
            
            LOGGER.debug("Drew splash at alpha: {}", alpha);
            
        } catch (Exception e) {
            LOGGER.error("Error drawing splash", e);
        }
    }

    public static boolean isActive() {
        return isShowing;
    }

    public static boolean hasCompleted() {
        return hasCompleted;
    }

    public static void reset() {
        startTime = 0;
        isShowing = false;
        hasCompleted = false;
        textureId = null;
    }
}