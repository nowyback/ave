package dev.albedo.ave.client.ui;

import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.fabricmc.api.EnvType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Splash overlay screen that displays the AVE splash before the main menu.
 * Renders the custom (d)AVE splash screen overlay.

 */
@Environment(EnvType.CLIENT)
public class SplashOverlayScreen extends class_437 {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-splash-overlay");
    
    public SplashOverlayScreen() {
        super(class_2561.method_43470("AVE Splash Overlay"));
        LOGGER.info("SplashOverlayScreen created");
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Render splash screen if still active
        if (AVESplashScreen.isActive()) {
            try {
                int width = this.field_22787.method_22683().method_4486();
                int height = this.field_22787.method_22683().method_4502();
                AVESplashScreen.renderSplashScreen(context, width, height);
            } catch (Exception e) {
                LOGGER.error("Error rendering splash", e);
            }
        } else {
            // Splash is done, transition to real TitleScreen
            LOGGER.info("Splash complete, showing TitleScreen");
            this.field_22787.method_1507(new class_442());
        }
    }
    
    @Override
    public boolean method_25422() {
        // Don't close while splash is active
        return !AVESplashScreen.isActive();
    }
    
    @Override
    public void method_25419() {
        if (!AVESplashScreen.isActive()) {
            super.method_25419();
        }
    }
}
