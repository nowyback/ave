package dev.albedo.ave.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import dev.albedo.ave.rendering.SSBOManager;
import dev.albedo.ave.rendering.gl.GLVersionDetector;
import dev.albedo.ave.rendering.CompatibilityTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// IMPORTANT: Ensure no code exists between your imports and this line!

@Environment(EnvType.CLIENT)
public class AVEClient implements ClientModInitializer {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave-client");
    
    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing Albedo Visual Engine - Client Side");
        
        // Initialize splash screen FIRST
        SplashScreenHandler.init();
        
        // Register key bindings
        AVEKeyBindings.register();
        
        // Run basic compatibility test
        CompatibilityTest.runBasicTest();
        
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            try {
                // Initialize OpenGL compatibility system
                SSBOManager manager = SSBOManager.getInstance();
                manager.initialize();
                
                // Log detected capabilities
                LOGGER.info("OpenGL Support Level: {}", GLVersionDetector.getSupportLevel());
                LOGGER.info("Render Mode: {}", manager.getRenderMode().displayName);
                
                if (manager.hasFullPerformance()) {
                    LOGGER.info("✓ GPU SSBO launched successfully - Full performance mode");
                } else if (manager.isFunctional()) {
                    LOGGER.info("✓ GPU rendering system active - Compatibility mode");
                } else {
                    LOGGER.warn("⚠ GPU rendering system disabled - Hardware not supported");
                }
            } catch (Exception e) {
                LOGGER.error("✗ Failed to initialize GPU SSBO system", e);
            }
        });
        
        // Register cleanup on shutdown
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            try {
                SSBOManager.getInstance().cleanup();
                LOGGER.info("GPU resources cleaned up on shutdown");
            } catch (Exception e) {
                LOGGER.error("Error during cleanup", e);
            }
        });
        
        LOGGER.info("Client initialization complete");
    }
}