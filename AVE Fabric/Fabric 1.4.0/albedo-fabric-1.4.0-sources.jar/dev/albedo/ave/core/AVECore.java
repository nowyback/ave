package dev.albedo.ave.core;

import net.fabricmc.api.ModInitializer;
import dev.albedo.ave.data.BlockAttributeLoader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Albedo Visual Engine (d)AVE main mod initializer.
 * Handles server-side initialization and block attribute loading.
 * 
 * @since 1.2.0
 */
public class AVECore implements ModInitializer {
    
    public static final String MOD_ID = "albedo-ave";
    public static final String MOD_NAME = "Albedo Visual Engine";
    public static final String VERSION = "1.4.0";
    
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    
    @Override
    public void onInitialize() {
        logStartup();
        
        try {
            // Load block attributes from JSON configs
            BlockAttributeLoader.loadAllConfigs();
            
            LOGGER.info("✓ {} v{} initialized successfully", MOD_NAME, VERSION);
            logStatistics();
            
        } catch (Exception e) {
            LOGGER.error("✗ Failed to initialize {}", MOD_NAME, e);
            throw new RuntimeException("Failed to initialize " + MOD_NAME, e);
        }
    }
    
    private static void logStartup() {
        LOGGER.info("");
        LOGGER.info("╔══════════════════════════════════════════════════════╗");
        LOGGER.info("║   Albedo Visual Engine - Data-Driven GPU Rendering   ║");
        LOGGER.info("║                     v1.4.0                           ║");
        LOGGER.info("║          https://github.com/yourusername/ave        ║");
        LOGGER.info("╚══════════════════════════════════════════════════════╝");
        LOGGER.info("");
    }
    
    private static void logStatistics() {
        BlockPropertyRegistry registry = BlockPropertyRegistry.getInstance();
        LOGGER.info("Registry Statistics:");
        LOGGER.info("  - Registered blocks: {}", registry.getRegisteredCount());
        LOGGER.info("");
    }
}
