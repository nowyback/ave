package dev.albedo.ave.core;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2248;
import net.minecraft.class_7923;
import dev.albedo.ave.data.BlockAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Thread-safe registry for block rendering attributes.
 * Maintains a 1:1 mapping of Block ID → BlockAttribute.
 * 
 * @since 1.4.0
 */
public class BlockPropertyRegistry {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("albedo-ave");
    private static final BlockPropertyRegistry INSTANCE = new BlockPropertyRegistry();
    private static final BlockAttribute DEFAULT_ATTRIBUTE = BlockAttribute.createDefault();
    
    private final Map<Integer, BlockAttribute> attributes = new ConcurrentHashMap<>();
    private final Map<class_2248, Integer> blockToId = new ConcurrentHashMap<>();
    private volatile boolean isDirty = false;
    
    private BlockPropertyRegistry() {}
    
    public static BlockPropertyRegistry getInstance() {
        return INSTANCE;
    }
    
    public void register(class_2248 block, BlockAttribute attribute) {
        Objects.requireNonNull(block, "Block cannot be null");
        Objects.requireNonNull(attribute, "BlockAttribute cannot be null");
        
        int blockId = getBlockId(block);
        if (blockId == -1) {
            LOGGER.warn("Failed to register block {}: invalid block ID", block);
            return;
        }
        
        attributes.put(blockId, attribute);
        blockToId.put(block, blockId);
        isDirty = true;
        
        LOGGER.debug("Registered block {} with ID {} → {}", 
            block.method_63499(), blockId, attribute);
    }
    
    public void registerBatch(Map<class_2248, BlockAttribute> entries) {
        Objects.requireNonNull(entries, "entries cannot be null");
        int successCount = 0;
        for (Map.Entry<class_2248, BlockAttribute> entry : entries.entrySet()) {
            try {
                register(entry.getKey(), entry.getValue());
                successCount++;
            } catch (Exception e) {
                LOGGER.error("Error registering block batch", e);
            }
        }
        LOGGER.info("Batch registration: {} blocks registered successfully", successCount);
    }
    
    public BlockAttribute get(class_2248 block) {
        Objects.requireNonNull(block, "Block cannot be null");
        int blockId = getBlockId(block);
        return attributes.getOrDefault(blockId, DEFAULT_ATTRIBUTE);
    }
    
    public BlockAttribute getById(int blockId) {
        return attributes.getOrDefault(blockId, DEFAULT_ATTRIBUTE);
    }
    
    public int[] packToBuffer() {
        if (attributes.isEmpty()) {
            LOGGER.warn("No block attributes registered, returning empty buffer");
            return new int[0];
        }
        
        int maxBlockId = attributes.keySet().stream()
            .mapToInt(Integer::intValue)
            .max()
            .orElse(0);
        
        int[] buffer = new int[maxBlockId + 1];
        
        for (int i = 0; i < buffer.length; i++) {
            buffer[i] = DEFAULT_ATTRIBUTE.pack();
        }
        
        attributes.forEach((blockId, attr) -> {
            if (blockId >= 0 && blockId < buffer.length) {
                buffer[blockId] = attr.pack();
            } else {
                LOGGER.warn("Block ID {} out of buffer bounds [0, {})", blockId, buffer.length);
            }
        });
        
        LOGGER.info("Packed {} block attributes (buffer size: {} bytes)", 
            attributes.size(), buffer.length * 4);
        
        return buffer;
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void clearDirtyFlag() {
        isDirty = false;
    }
    
    public int getRegisteredCount() {
        return attributes.size();
    }
    
    private int getBlockId(class_2248 block) {
        try {
            return class_7923.field_41175.method_10206(block);
        } catch (Exception e) {
            LOGGER.error("Failed to get block ID for {}", block, e);
            return -1;
        }
    }
    
    public void clear() {
        attributes.clear();
        blockToId.clear();
        isDirty = true;
        LOGGER.info("Block attribute registry cleared");
    }
}
